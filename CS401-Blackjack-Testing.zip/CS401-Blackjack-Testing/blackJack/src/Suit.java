public enum Suit {
	Hearts, Diamonds, Clubs, Spades;
}
