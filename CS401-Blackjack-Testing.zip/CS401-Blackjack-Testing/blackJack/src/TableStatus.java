
public enum TableStatus {
	Open, Full, Empty, NeedDealer;
}
